﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddUser.xaml
    /// </summary>
    public partial class AddUser : Page
    {
        public Employee _currentItem = new Employee();
        public AddUser(Employee selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
            }
            DataContext = _currentItem;
            cmbType.ItemsSource = ClassFrame.db.TypesEmployee.ToList();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (txtFIO.Text == "" && txtLogin.Text == "" && txtPassword.Text == "" && cmbType.Text == "")
            {
                MessageBox.Show("Введите данные в поле", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (_currentItem.IdEmployee == 0) ClassFrame.db.Employee.Add(_currentItem);
            try
            {
                ClassFrame.db.SaveChanges();
                ClassFrame.frmObj.Navigate(new User());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new User());
        }
    }
}
