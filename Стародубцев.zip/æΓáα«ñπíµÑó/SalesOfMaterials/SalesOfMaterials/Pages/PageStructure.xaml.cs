﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageStructure.xaml
    /// </summary>
    public partial class PageStructure : Page
    {

        public readonly Materials _material = new Materials();
        public PageStructure(int idMaterial)
        {
            InitializeComponent();
            _material = ClassFrame.db.Database.SqlQuery<Materials>("select * from Nomenclature.dbo.Materials").FirstOrDefault(x => x.idMaterial == idMaterial);

            foreach (Hierarchy hierarchy in ClassFrame.db.Database.SqlQuery<Hierarchy>("select * from Nomenclature.dbo.Hierarchy").Where(x => x.idParent == _material.idMaterial).ToList())
            {
                TreeViewItem tree = new TreeViewItem();
                tree.Header = hierarchy.Material1.Name;
                foreach(Hierarchy hierarchy1 in ClassFrame.db.Database.SqlQuery<Hierarchy>("select * from Nomenclature.dbo.Hierarchy").Where(x => x.idParent == hierarchy.Material1.idMaterial).ToList())
                {
                    TreeViewItem tree1 = new TreeViewItem();
                    tree1.Header = hierarchy1.Material1.Name;
                    tree.Items.Add(tree1);
                }
                trStructure.Items.Add(tree);
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ListOfMaterials());
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new ListOfMaterials());
        }
    }
}
